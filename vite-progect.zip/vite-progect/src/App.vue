<script setup>
import { ref } from "vue";

const newTask = ref("");
const tasks = ref([]);

function addTask() {
  if (newTask.value.trim() !== "") {
    tasks.value.push({
      text: newTask.value.trim(),
      done: false,
    });
    newTask.value = "";
  }
}

function toggleDone(index) {
  tasks.value[index].done = !tasks.value[index].done;
}
</script>

<template>
  <div class="todo-container">
    <h2>Список дел</h2>

    <input
      v-model="newTask"
      @keyup.enter="addTask"
      placeholder="Добавить задачу..."
    />

    <ul>
      <li
        v-for="(task, index) in tasks"
        :key="index"
        :class="{ done: task.done }"
        @click="toggleDone(index)"
      >
        {{ task.text }}
      </li>
    </ul>
  </div>
</template>

<style scoped>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: #f5f5f5;
}

.todo-container {
  width: 400px;
  margin: 40px auto;
  background: white;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.todo-container h2 {
  text-align: center;
}
input {
  width: 95%;
  padding: 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
}

ul {
  padding-left: 20px;
}

li {
  padding: 8px 0;
  cursor: pointer;
  transition: 0.2s;
}

li:hover {
  color: #333;
}

.done {
  text-decoration: line-through;
  color: gray;
  opacity: 0.7;
}
</style>
